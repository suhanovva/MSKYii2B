<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'Отчеты';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-zakaz">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        Страница Отчетов:
    </p>

    <code><?= __FILE__ ?></code>
	
</div>
