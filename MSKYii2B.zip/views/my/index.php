<h1>Action Index</h1>
<?= $hi ?>
<br/>

<?= $id ?>

<br/>

<?php

foreach ($names as $name) {
    echo $name . '<br>';
}
